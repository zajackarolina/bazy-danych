INSERT INTO rozliczenia.pensje (id_pensji, stanowisko, kwota, id_premii)
VALUES
    ('1', 'Kierownik', '5000', '101'),
    ('2', 'Specjalista', '4000', '102'),
    ('3', 'Asystent', '3000', '103'),
    ('4', 'Programista', '4500', '104'),
    ('5', 'Analityk', '4200', '105'),
    ('6', 'Kierownik', '5100', '106'),
    ('7', 'Specjalista', '4100', '107'),
    ('8', 'Asystent', '3200', '108'),
    ('9', 'Programista', '4600', '109'),
    ('10', 'Analityk', '4300', '110');
