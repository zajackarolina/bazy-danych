INSERT INTO rozliczenia.premie (id_premii, rodzaj, kwota)
VALUES
    ('1', 'Premia 1', '500'),
    ('2', 'Premia 2', '400'),
    ('3', 'Premia 3', '300'),
    ('4', 'Premia 4', '450'),
    ('5', 'Premia 5', '420'),
    ('6', 'Premia 6', '510'),
    ('7', 'Premia 7', '410'),
    ('8', 'Premia 8', '320'),
    ('9', 'Premia 9', '460'),
    ('10', 'Premia 10', '430');
