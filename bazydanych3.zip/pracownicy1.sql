INSERT INTO pracownicy (id_pracownika, telefon, adres, nazwisko, imie)
VALUES
    ('1', '123-456-789', 'ul. Długa 123', 'Kowalski', 'Jan'),
    ('2', '987-654-321', 'ul. Krótka 45', 'Nowak', 'Anna'),
    ('3', '555-123-456', 'ul. Prosta 67', 'Smith', 'John'),
    ('4', '111-222-333', 'ul. Wąska 89', 'Garcia', 'Maria'),
    ('5', '444-555-666', 'ul. Słoneczna 12', 'Nowacki', 'Andrzej'),
    ('6', '777-888-999', 'ul. Cicha 34', 'Kowalczyk', 'Ewa'),
    ('7', '333-222-111', 'ul. Morska 76', 'Wójcik', 'Marta'),
    ('8', '222-333-444', 'ul. Górska 56', 'Lis', 'Piotr'),
    ('9', '888-777-666', 'ul. Polna 78', 'Mazur', 'Karolina'),
    ('10', '999-555-111', 'ul. Leśna 90', 'Nowakowski', 'Robert');
