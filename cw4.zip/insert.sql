INSERT INTO ksiegowosc.pracownicy (id_pracownika, imie, nazwisko, adres, telefon)
VALUES
  (1, 'Jan', 'Kowalski', 'ul. Słoneczna 1, Warszawa', '123-456-789'),
  (2, 'Anna', 'Nowak', 'ul. Kwiatowa 2, Kraków', '987-654-321'),
  (3, 'Piotr', 'Nowakowski', 'ul. Leśna 3, Gdańsk', '555-555-555'),
  (4, 'Maria', 'Lis', 'ul. Polna 4, Poznań', '111-222-333'),
  (5, 'Andrzej', 'Wójcik', 'ul. Rycerska 5, Łódź', '777-888-999'),
  (6, 'Ewa', 'Kaczmarek', 'ul. Morska 6, Wrocław', '444-333-222'),
  (7, 'Tomasz', 'Zieliński', 'ul. Górska 7, Katowice', '999-111-222'),
  (8, 'Magdalena', 'Szymańska', 'ul. Ogrodowa 8, Lublin', '666-777-888'),
  (9, 'Krzysztof', 'Dąbrowski', 'ul. Jesienna 9, Szczecin', '123-987-456'),
  (10, 'Agnieszka', 'Kwiatkowska', 'ul. Wiejska 10', '333-222-111');
